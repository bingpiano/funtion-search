package srctest;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
                                   /*测试顺序:*/
//第一个运行         (运行顺序GenerateLinearData -> OptimizedMinimaxLinearFitter -> Main)

                                    /*类介绍*/
//测试时，该类如无其他需求，可直接运行
//该类用来产生自定义数量的升序数据，并存于savePath中。
//interval仅为了让数据不保持近似线性增长
//defaultMinIncrement于defaultMaxIncrement为该组数据开始时的增长量

                                    /*默认配置*/
//100000000个递增数据，函数走向在第20000000个数据后变为平缓，第35000000个数据后更加平缓，在第70000000个数据恢复原增长量

public class GenerateLinearData {
    private static final String savePath = "increasing_data.txt";
    //数据量
    private static final int dataCount = 100000000;
    //第一个数据变化点
    private static final double interval1=0.2*dataCount;
    //第二个数据变化点
    private static final double interval2=0.35*dataCount;
    //第三个数据变化点
    private static final double interval3=0.7*dataCount;
    //数据初始值
    private static final int defaultCurrentValue = 10;
    //数据最小增长量
    private static final int defaultMinIncrement = 1;
    //数据最大增长量
    private static final int defaultMaxIncrement = 20;

    public static List<Integer> generateIncreasingData(int count) {
        List<Integer> yList = new ArrayList<>(count);
        Random random = new Random();

        int currentValue = defaultCurrentValue;
        int minIncrement = defaultMinIncrement;
        int maxIncrement = defaultMaxIncrement;


        yList.add(currentValue);

        for (int i = 1; i < count; i++) {
            int increment = random.nextInt(maxIncrement - minIncrement + 1) + minIncrement;
            currentValue += increment;
            yList.add(currentValue);
            if(count>interval1){
                //此处maxIncrement可根据需求更改
                maxIncrement=6;
            }
            if(count>interval2){
                //此处maxIncrement可根据需求更改
                maxIncrement=30;
            }
            if(count>interval3){
                //此处maxIncrement可根据需求更改
                maxIncrement=20;
            }
        }
        return yList;
    }

    public static void saveDataToFile(List<Integer> data, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < data.size(); i++) {
                writer.write(String.valueOf(data.get(i)));
                if (i < data.size() - 1) {
                    writer.write(",");
                }

                if ((i + 1) % 50 == 0) {
                    writer.newLine();
                }
            }
            System.out.println("数据已成功保存到：" + filePath);
        } catch (IOException e) {
            System.err.println("保存文件失败：" + e.getMessage());
        }
    }



    public static void main(String[] args) {
        List<Integer> yList = generateIncreasingData(dataCount);
        saveDataToFile(yList, savePath);
    }
}
