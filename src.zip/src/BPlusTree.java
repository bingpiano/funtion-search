import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
//该类仅为B-tree工具类，无需运行
public class BPlusTree<T extends Comparable<T>> {
    private final int order;
    private final int maxKeys;
    private final int minKeys;
    private Node<T> root;

    public BPlusTree(int order) {
        if (order < 3) {
            throw new IllegalArgumentException("error");
        }
        this.order = order;
        this.maxKeys = order - 1;
        this.minKeys = (order - 1) / 2;
        this.root = new LeafNode<>();
    }

    private abstract static class Node<T extends Comparable<T>> {
        protected final List<T> keys;

        Node() {
            keys = new ArrayList<>();
        }

        abstract boolean isFull(int maxKeys);
        abstract boolean isUnderflow(int minKeys);
        abstract int findChildIndex(T key);
        abstract boolean isLeaf();
        abstract boolean search(T key);
    }

    private class InternalNode<T extends Comparable<T>> extends Node<T> {
        private final List<Node<T>> children;

        InternalNode() {
            super();
            children = new ArrayList<>();
        }

        @Override
        boolean isFull(int maxKeys) {
            return keys.size() > maxKeys;
        }

        @Override
        boolean isUnderflow(int minKeys) {
            return keys.size() < minKeys;
        }

        @Override
        int findChildIndex(T key) {
            int left = 0;
            int right = keys.size() - 1;

            while (left <= right) {
                int mid = (left + right) >>> 1;
                int cmp = key.compareTo(keys.get(mid));

                if (cmp < 0) {
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            }
            return left;
        }

        @Override
        boolean isLeaf() {
            return false;
        }

        @Override
        boolean search(T key) {
            int index = findChildIndex(key);
            return children.get(index).search(key);
        }
    }

    private class LeafNode<T extends Comparable<T>> extends Node<T> {
        private LeafNode<T> next;
        private final List<Long> dataPointers;

        LeafNode() {
            super();
            dataPointers = new ArrayList<>();
        }

        @Override
        boolean isFull(int maxKeys) {
            return keys.size() > maxKeys;
        }

        @Override
        boolean isUnderflow(int minKeys) {
            return keys.size() < minKeys;
        }

        @Override
        int findChildIndex(T key) {
            return Collections.binarySearch(keys, key);
        }

        @Override
        boolean isLeaf() {
            return true;
        }

        @Override
        boolean search(T key) {
            return Collections.binarySearch(keys, key) >= 0;
        }
    }

    public void insert(T key, Long dataPointer) {
        InsertResult<T> result = insert(root, key, dataPointer);
        if (result.newChild != null) {
            InternalNode<T> newRoot = new InternalNode<>();
            newRoot.keys.add(result.splitKey);
            newRoot.children.add(root);
            newRoot.children.add(result.newChild);
            root = newRoot;
        }
    }

    private InsertResult<T> insert(Node<T> node, T key, Long dataPointer) {
        if (node.isLeaf()) {
            return insertIntoLeaf((LeafNode<T>) node, key, dataPointer);
        } else {
            InternalNode<T> internalNode = (InternalNode<T>) node;
            int index = internalNode.findChildIndex(key);
            InsertResult<T> result = insert(internalNode.children.get(index), key, dataPointer);

            if (result.newChild != null) {
                int insertIndex = internalNode.findChildIndex(result.splitKey);
                internalNode.keys.add(insertIndex, result.splitKey);
                internalNode.children.add(insertIndex + 1, result.newChild);

                if (internalNode.isFull(maxKeys)) {
                    return splitInternalNode(internalNode);
                }
            }
            return new InsertResult<>(null, null);
        }
    }

    private InsertResult<T> insertIntoLeaf(LeafNode<T> leaf, T key, Long dataPointer) {
        int index = Collections.binarySearch(leaf.keys, key);
        if (index < 0) {
            index = -index - 1;
        }

        leaf.keys.add(index, key);
        leaf.dataPointers.add(index, dataPointer);

        if (leaf.isFull(maxKeys)) {
            return splitLeafNode(leaf);
        }
        return new InsertResult<>(null, null);
    }

    private InsertResult<T> splitLeafNode(LeafNode<T> leaf) {
        int splitIndex = leaf.keys.size() / 2;
        T splitKey = leaf.keys.get(splitIndex);

        LeafNode<T> newLeaf = new LeafNode<>();
        newLeaf.keys.addAll(leaf.keys.subList(splitIndex, leaf.keys.size()));
        newLeaf.dataPointers.addAll(leaf.dataPointers.subList(splitIndex, leaf.dataPointers.size()));

        leaf.keys.subList(splitIndex, leaf.keys.size()).clear();
        leaf.dataPointers.subList(splitIndex, leaf.dataPointers.size()).clear();

        newLeaf.next = leaf.next;
        leaf.next = newLeaf;

        return new InsertResult<>(splitKey, newLeaf);
    }

    private InsertResult<T> splitInternalNode(InternalNode<T> node) {
        int splitIndex = node.keys.size() / 2;
        T splitKey = node.keys.get(splitIndex);

        InternalNode<T> newNode = new InternalNode<>();
        newNode.keys.addAll(node.keys.subList(splitIndex + 1, node.keys.size()));
        newNode.children.addAll(node.children.subList(splitIndex + 1, node.children.size()));

        node.keys.subList(splitIndex, node.keys.size()).clear();
        node.children.subList(splitIndex + 1, node.children.size()).clear();

        return new InsertResult<>(splitKey, newNode);
    }

    public boolean search(T value) {
        return root.search(value);
    }

    private static class InsertResult<T extends Comparable<T>> {
        final T splitKey;
        final Node<T> newChild;

        InsertResult(T splitKey, Node<T> newChild) {
            this.splitKey = splitKey;
            this.newChild = newChild;
        }
    }

    public void insertBatch(T[] keys, Long[] dataPointers) {
        for (int i = 0; i < keys.length; i++) {
            insert(keys[i], dataPointers[i]);
        }
    }
}