import java.io.*;
import java.util.ArrayList;
                                    /*测试顺序:*/
//第二个运行     (运行顺序GenerateLinearData -> LinearFitter -> Main)

                                    /*类介绍*/
//测试时，该类如无其他需求，可直接运行
//该类用来生成拟合函数，并将k，b，maxError保存于dataFilePath中
//可根据需要改为特定拟合函数
public class LinearFitter {
    private static final String dataFilePath = "increasing_data.txt";


    public static int[] readIntegerData(String filePath) throws IOException {
        int[] tempArray = new int[10];
        int size = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                int[] lineData = processLine(line);

                while (size + lineData.length > tempArray.length) {
                    int[] newArray = new int[tempArray.length * 2];
                    System.arraycopy(tempArray, 0, newArray, 0, size);
                    tempArray = newArray;
                }

                System.arraycopy(lineData, 0, tempArray, size, lineData.length);
                size += lineData.length;
            }
        }

        int[] result = new int[size];
        System.arraycopy(tempArray, 0, result, 0, size);
        return result;
    }


    private static int[] processLine(String line) {
        String trimmedLine = line.trim();
        if (trimmedLine.isEmpty()) {
            return new int[0];
        }

        String[] dataStrArray = trimmedLine.split(",");
        int[] lineData = new int[dataStrArray.length];
        int count = 0;

        for (String dataStr : dataStrArray) {
            String trimmedData = dataStr.trim();
            if (!trimmedData.isEmpty()) {
                try {
                    lineData[count++] = Integer.parseInt(trimmedData);
                } catch (NumberFormatException e) {
                    System.err.println("警告：跳过无效整数格式的数据 - " + trimmedData);
                }
            }
        }

        if (count < dataStrArray.length) {
            int[] result = new int[count];
            System.arraycopy(lineData, 0, result, 0, count);
            return result;
        }
        return lineData;
    }

    public static double[] linearFit(int[] yArray) {
        if (yArray == null || yArray.length < 2) {
            throw new IllegalArgumentException("error");
        }

        return linearFitWithX(yArray);
    }

    private static double[] linearFitWithX(int[] yArray) {
        int n = yArray.length;
        long sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

        for (int i = 0; i < n; i++) {
            int x = i;
            int y = yArray[i];
            sumX += x;
            sumY += y;
            sumXY += (long) x * y;
            sumX2 += (long) x * x;
        }

        double denominator = n * sumX2 - (double) sumX * sumX;
        if (denominator == 0) {
            throw new ArithmeticException("error");
        }
        double k = (n * sumXY - (double) sumX * sumY) / denominator;
        double b = ((double) sumY - k * sumX) / n;

        return new double[]{k, b};
    }

    public static double calculateR2(int[] yArray, double k, double b) {
        int n = yArray.length;
        double sumY = 0;

        for (int y : yArray) {
            sumY += y;
        }
        double yMean = sumY / n;

        double ssTotal = 0;
        double ssResidual = 0;

        for (int i = 0; i < n; i++) {
            int x = i;
            int yActual = yArray[i];
            double yPredicted = k * x + b;

            ssTotal += Math.pow(yActual - yMean, 2);
            ssResidual += Math.pow(yActual - yPredicted, 2);
        }

        return 1 - ssResidual / ssTotal;
    }

    public static double calculateMaxError(int[] yArray, double k, double b) {
        System.out.println("开始测试maxError");
        System.out.println("yArrayLength="+yArray.length+"k="+k+"b="+b);
        double maxError=0;
        double error;
        for (int i = 0; i < yArray.length; i++) {
            error = Math.abs(yArray[i]-(k*i+b));
            if(error>maxError) {
                maxError = error;
            }
        }
        return maxError;
    }


    public static void saveMaxError(String filePath, double maxError,double k,double b) {
        ArrayList<Double> data = new ArrayList();
        data.add(maxError);
        data.add(k);
        data.add(b);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < data.size(); i++) {
                writer.write(String.valueOf(data.get(i)));
                if (i < data.size() - 1) {
                    writer.write(",");
                }
                if ((i + 1) % 50 == 0) {
                    writer.newLine();
                }
            }
            System.out.println("最大误差已成功保存到：" + filePath);
        } catch (IOException e) {
            System.err.println("保存最大误差失败：" + e.getMessage());
        }
    }


    public static double readMaxError(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("最大误差文件不存在：" + filePath);
            return 0;
        }

        if (file.length() == 0) {
            System.out.println("最大误差文件为空：" + filePath);
            return 0;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line = reader.readLine();
            if (line == null || line.trim().isEmpty()) {
                System.out.println("最大误差文件内容为空：" + filePath);
                return 0;
            }

            return Double.parseDouble(line.trim());
        } catch (IOException e) {
            System.err.println("读取最大误差文件失败：" + e.getMessage());
            return 0;
        } catch (NumberFormatException e) {
            System.err.println("最大误差文件内容格式错误：" + e.getMessage());
            return 0;
        }
    }

    public static void main(String[] args) {
        String maxErrorFilePath = "max_error.txt";
        double existingMaxError = readMaxError(maxErrorFilePath);

        if (existingMaxError == 0) {
            System.out.println("没有找到有效的历史最大误差，将计算并保存新的最大误差");
            try {
                int[] data = readIntegerData(dataFilePath);
                if (data.length == 0) {
                    System.err.println("数据文件为空或没有有效数据");
                    return;
                }

                double[] params = linearFit(data);
                double k = params[0];
                double b = params[1];

                double r2 = calculateR2(data, k, b);
                double maxError = calculateMaxError(data, k, b);

                System.out.printf("线性拟合结果: y = %.4fx + %.4f%n", k, b);
                System.out.printf("决定系数 R²: %.4f%n", r2);
                System.out.printf("最大误差: %.4f%n", maxError);

                saveMaxError(maxErrorFilePath, maxError,k,b);

            } catch (IOException e) {
                System.err.println("读取数据文件失败：" + e.getMessage());
            } catch (IllegalArgumentException | ArithmeticException e) {
                System.err.println("拟合计算失败：" + e.getMessage());
            }
        } else {
            System.out.printf("已找到历史最大误差: %.4f%n", existingMaxError);
        }
    }
}
