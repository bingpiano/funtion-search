import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class OptimizedMinimaxLinearFitter {
    private static final String dataFilePath = "increasing_data.txt";
    private static final String maxErrorFilePath = "max_error.txt"; //△max

    private double[] y;
    private double[] x; // 预计算x值（索引1,2,...,n）
    private double a;   // 斜率
    private double b;   // 截距
    private int n;      // 数据点数量

    public OptimizedMinimaxLinearFitter(double[] yValues) {
        this.y = yValues.clone();
        this.n = yValues.length;
        this.x = new double[n];
        for (int i = 0; i < n; i++) {
            x[i] = i + 1; // 预计算x值并缓存
        }
        fit();
    }

    private void fit() {
        // 1. 先用最小二乘法快速估算初始参数（大幅减少后续迭代次数）
        double[] lsParams = leastSquaresFit();
        double initialA = lsParams[0];
        double initialB = lsParams[1];

        // 2. 用三点法迭代优化（针对线性拟合的高效算法）
        threePointOptimization(initialA, initialB);
    }

    // 最小二乘法估算初始参数（快速计算）
    private double[] leastSquaresFit() {
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        for (int i = 0; i < n; i++) {
            sumX += x[i];
            sumY += y[i];
            sumXY += x[i] * y[i];
            sumX2 += x[i] * x[i];
        }
        double denominator = n * sumX2 - sumX * sumX;
        if (denominator == 0) {
            return new double[]{0, sumY / n}; // 防止除零（x恒定时）
        }
        double a = (n * sumXY - sumX * sumY) / denominator;
        double b = (sumY - a * sumX) / n;
        return new double[]{a, b};
    }

    // 三点法迭代优化（利用切比雪夫逼近的特性）
    private void threePointOptimization(double initialA, double initialB) {
        double currentA = initialA;
        double currentB = initialB;
        double tolerance = 1e-8;
        int maxIter = 50; // 线性拟合收敛快，迭代次数可大幅减少

        for (int iter = 0; iter < maxIter; iter++) {
            // 找到当前偏差最大的3个点（符号交替）
            int[] extremeIndices = findExtremePoints(currentA, currentB);
            if (extremeIndices == null) break; // 已满足条件

            // 基于3个点计算新的参数（解析解）
            double[] newParams = solveThreePoints(extremeIndices);
            double newA = newParams[0];
            double newB = newParams[1];

            // 计算参数变化量，小于阈值则停止
            if (Math.abs(newA - currentA) < tolerance && Math.abs(newB - currentB) < tolerance) {
                currentA = newA;
                currentB = newB;
                break;
            }

            currentA = newA;
            currentB = newB;
        }

        this.a = currentA;
        this.b = currentB;
    }

    // 找到偏差最大且符号交替的3个点
    private int[] findExtremePoints(double a, double b) {
        // 计算所有点的偏差
        double[] deviations = new double[n];
        for (int i = 0; i < n; i++) {
            deviations[i] = y[i] - (a * x[i] + b);
        }

        // 找到绝对值最大的前3个点
        int[] indices = new int[3];
        double[] values = new double[3];
        Arrays.fill(values, -1);

        for (int i = 0; i < n; i++) {
            double absDev = Math.abs(deviations[i]);
            for (int j = 0; j < 3; j++) {
                if (absDev > values[j]) {
                    // 插入到排序位置
                    for (int k = 2; k > j; k--) {
                        values[k] = values[k - 1];
                        indices[k] = indices[k - 1];
                    }
                    values[j] = absDev;
                    indices[j] = i;
                    break;
                }
            }
        }

        // 检查是否符号交替（切比雪夫最优解的必要条件）
        double d0 = deviations[indices[0]];
        double d1 = deviations[indices[1]];
        double d2 = deviations[indices[2]];
        if ((d0 > 0 && d1 < 0 && d2 > 0) || (d0 < 0 && d1 > 0 && d2 < 0)) {
            return indices;
        } else {
            return null; // 已满足最优条件
        }
    }

    // 基于3个点计算最优参数（解析解）
    private double[] solveThreePoints(int[] indices) {
        int i = indices[0], j = indices[1], k = indices[2];
        double xi = x[i], yi = y[i];
        double xj = x[j], yj = y[j];
        double xk = x[k], yk = y[k];

        // 符号系数（交替为+1和-1）
        double s1 = 1, s2 = -1, s3 = 1;

        // 解方程组：
        // yi - (a*xi + b) = s1 * E
        // yj - (a*xj + b) = s2 * E
        // yk - (a*xk + b) = s3 * E
        double denominator = s1*(xj - xk) + s2*(xk - xi) + s3*(xi - xj);
        if (denominator == 0) {
            return new double[]{a, b}; // 防止除零
        }

        double a = (s1*(yj - yk) + s2*(yk - yi) + s3*(yi - yj)) / denominator;
        double E = (yi - yj) + a*(xj - xi);
        E /= (s1 - s2);
        double b = yi - a*xi - s1*E;

        return new double[]{a, b};
    }

    // 计算当前参数的最大偏差（优化版：直接用缓存的x数组）
    public double getMaxDeviation() {
        double max = 0;
        for (int i = 0; i < n; i++) {
            double dev = Math.abs(y[i] - (a * x[i] + b));
            if (dev > max) max = dev;
        }
        return max;
    }

    // Getters
    public double getSlope() { return a; }
    public double getIntercept() { return b; }

    // 测试示例
    public static void main(String[] args) throws IOException {
        double[] y = readDoubleData(dataFilePath); // 更大的测试数据
        long start = System.nanoTime();

        OptimizedMinimaxLinearFitter fitter = new OptimizedMinimaxLinearFitter(y);

        long end = System.nanoTime();
        LinearFitter.saveMaxError(maxErrorFilePath,fitter.getMaxDeviation(),fitter.getSlope(),fitter.getIntercept());
        System.out.println("最优拟合：y = " + fitter.getSlope() + "x + " + fitter.getIntercept());
        System.out.println("最大偏差：" + fitter.getMaxDeviation());
        System.out.println("耗时：" + (end - start) / 1000 + " 微秒");
    }
    public static double[] readDoubleData(String filePath) throws IOException {
        double[] tempArray = new double[10];
        int size = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                double[] lineData = processLine(line);

                while (size + lineData.length > tempArray.length) {
                    double[] newArray = new double[tempArray.length * 2];
                    System.arraycopy(tempArray, 0, newArray, 0, size);
                    tempArray = newArray;
                }

                System.arraycopy(lineData, 0, tempArray, size, lineData.length);
                size += lineData.length;
            }
        }

        double[] result = new double[size];
        System.arraycopy(tempArray, 0, result, 0, size);
        return result;
    }
    private static double[] processLine(String line) {
        String trimmedLine = line.trim();
        if (trimmedLine.isEmpty()) {
            return new double[0];
        }

        String[] dataStrArray = trimmedLine.split(",");
        double[] lineData = new double[dataStrArray.length];
        int count = 0;

        for (String dataStr : dataStrArray) {
            String trimmedData = dataStr.trim();
            if (!trimmedData.isEmpty()) {
                try {
                    lineData[count++] = Integer.parseInt(trimmedData);
                } catch (NumberFormatException e) {
                    System.err.println("警告：跳过无效整数格式的数据 - " + trimmedData);
                }
            }
        }

        if (count < dataStrArray.length) {
            double[] result = new double[count];
            System.arraycopy(lineData, 0, result, 0, count);
            return result;
        }
        return lineData;
    }
}
