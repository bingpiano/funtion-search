package srctest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class MinimaxLinearFitter {
    private static final String dataFilePath = "increasing_data1.txt";

    // 数据点：y值数组（x为索引1,2,...,n）
    private double[] y;
    // 最优参数：a（斜率）、b（截距）
    private double a;
    private double b;



    public MinimaxLinearFitter(double[] yValues) {
        this.y = yValues.clone();
        fit(); // 构造时自动拟合
    }

    // 执行拟合
    private void fit() {
        // 初始猜测参数：a=0, b=均值（简单初始化）
        double initialA = 0;
        double initialB = Arrays.stream(y).average().orElse(0);
        double[] initialGuess = {initialA, initialB};

        // 使用Nelder-Mead算法优化
        double[] optimalParams = nelderMead(initialGuess, 1e-6, 10000);
        this.a = optimalParams[0];
        this.b = optimalParams[1];
    }

    // 目标函数：计算当前参数(a,b)对应的最大偏差
    private double objectiveFunction(double[] params) {
        double a = params[0];
        double b = params[1];
        double maxDeviation = 0;
        for (int i = 0; i < y.length; i++) {
            double x = i + 1; // x为索引（1-based）
            double predicted = a * x + b;
            double deviation = Math.abs(y[i] - predicted);
            if (deviation > maxDeviation) {
                maxDeviation = deviation;
            }
        }
        return maxDeviation;
    }

    // Nelder-Mead单纯形法实现
    private double[] nelderMead(double[] initialGuess, double tolerance, int maxIterations) {
        int n = initialGuess.length; // 参数维度（这里n=2）
        double alpha = 1.0;    // 反射系数
        double gamma = 2.0;    // 扩张系数
        double rho = 0.5;      // 收缩系数
        double sigma = 0.5;    // 压缩系数

        // 初始化单纯形（n+1个点）
        double[][] simplex = new double[n + 1][n];
        simplex[0] = initialGuess.clone();
        for (int i = 0; i < n; i++) {
            simplex[i + 1] = initialGuess.clone();
            simplex[i + 1][i] += (simplex[i + 1][i] == 0) ? 0.05 : 0.05 * simplex[i + 1][i];
        }

        // 迭代优化
        int iterations = 0;
        while (iterations < maxIterations) {
            // 计算每个点的目标函数值并排序
            double[] values = new double[n + 1];
            for (int i = 0; i < n + 1; i++) {
                values[i] = objectiveFunction(simplex[i]);
            }
            int[] sortedIndices = argsort(values); // 升序排序的索引

            // 检查收敛条件（最差与最好的差值小于 tolerance）
            if (values[sortedIndices[n]] - values[sortedIndices[0]] < tolerance) {
                break;
            }

            // 计算除最差点外的重心
            double[] centroid = new double[n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) { // 排除最后一个（最差）点
                    centroid[j] += simplex[sortedIndices[i]][j];
                }
            }
            for (int j = 0; j < n; j++) {
                centroid[j] /= n;
            }

            // 反射（最差点关于重心的反射）
            double[] worst = simplex[sortedIndices[n]];
            double[] reflected = new double[n];
            for (int j = 0; j < n; j++) {
                reflected[j] = centroid[j] + alpha * (centroid[j] - worst[j]);
            }
            double fReflected = objectiveFunction(reflected);

            if (fReflected < values[sortedIndices[0]]) {
                // 反射点更好，尝试扩张
                double[] expanded = new double[n];
                for (int j = 0; j < n; j++) {
                    expanded[j] = centroid[j] + gamma * (reflected[j] - centroid[j]);
                }
                double fExpanded = objectiveFunction(expanded);
                simplex[sortedIndices[n]] = (fExpanded < fReflected) ? expanded : reflected;
            } else if (fReflected < values[sortedIndices[n - 1]]) {
                // 反射点介于最好和次差之间，接受反射点
                simplex[sortedIndices[n]] = reflected;
            } else {
                // 反射点较差，尝试收缩
                double[] contracted = new double[n];
                if (fReflected < values[sortedIndices[n]]) {
                    // 收缩到反射点和重心之间
                    for (int j = 0; j < n; j++) {
                        contracted[j] = centroid[j] + rho * (reflected[j] - centroid[j]);
                    }
                } else {
                    // 收缩到最差点和重心之间
                    for (int j = 0; j < n; j++) {
                        contracted[j] = centroid[j] - rho * (centroid[j] - worst[j]);
                    }
                }
                double fContracted = objectiveFunction(contracted);
                if (fContracted < values[sortedIndices[n]]) {
                    simplex[sortedIndices[n]] = contracted;
                } else {
                    // 整体收缩（向最好点靠近）
                    for (int i = 1; i < n + 1; i++) {
                        for (int j = 0; j < n; j++) {
                            simplex[sortedIndices[i]][j] = simplex[sortedIndices[0]][j] +
                                    sigma * (simplex[sortedIndices[i]][j] - simplex[sortedIndices[0]][j]);
                        }
                    }
                }
            }

            iterations++;
        }

        // 返回最优参数（目标函数值最小的点）
        double[] bestParams = simplex[0];
        double bestValue = objectiveFunction(bestParams);
        for (double[] param : simplex) {
            double val = objectiveFunction(param);
            if (val < bestValue) {
                bestValue = val;
                bestParams = param;
            }
        }
        return bestParams;
    }

    // 辅助函数：返回数组升序排序的索引
    private int[] argsort(double[] array) {
        Integer[] indices = new Integer[array.length];
        for (int i = 0; i < indices.length; i++) {
            indices[i] = i;
        }
        Arrays.sort(indices, (i, j) -> Double.compare(array[i], array[j]));
        return Arrays.stream(indices).mapToInt(Integer::intValue).toArray();
    }

    // 获取拟合结果
    public double getSlope() { return a; }
    public double getIntercept() { return b; }

    // 计算最大偏差
    public double getMaxDeviation() {
        double max = 0;
        for (int i = 0; i < y.length; i++) {
            double x = i + 1;
            double deviation = Math.abs(y[i] - (a * x + b));
            max = Math.max(max, deviation);
        }
        return max;
    }

    // 示例用法
    public static void main(String[] args) throws IOException {
        // 测试数据：升序y值（x为索引1,2,3,4,5）
        double[] y = readDoubleData(dataFilePath);

        MinimaxLinearFitter fitter = new MinimaxLinearFitter(y);

        System.out.println("最优线性拟合：y = " + fitter.getSlope() + "x + " + fitter.getIntercept());
        System.out.println("最大偏差：" + fitter.getMaxDeviation());
    }

    public static double[] readDoubleData(String filePath) throws IOException {
        double[] tempArray = new double[10];
        int size = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                double[] lineData = processLine(line);

                while (size + lineData.length > tempArray.length) {
                    double[] newArray = new double[tempArray.length * 2];
                    System.arraycopy(tempArray, 0, newArray, 0, size);
                    tempArray = newArray;
                }

                System.arraycopy(lineData, 0, tempArray, size, lineData.length);
                size += lineData.length;
            }
        }

        double[] result = new double[size];
        System.arraycopy(tempArray, 0, result, 0, size);
        return result;
    }
    private static double[] processLine(String line) {
        String trimmedLine = line.trim();
        if (trimmedLine.isEmpty()) {
            return new double[0];
        }

        String[] dataStrArray = trimmedLine.split(",");
        double[] lineData = new double[dataStrArray.length];
        int count = 0;

        for (String dataStr : dataStrArray) {
            String trimmedData = dataStr.trim();
            if (!trimmedData.isEmpty()) {
                try {
                    lineData[count++] = Integer.parseInt(trimmedData);
                } catch (NumberFormatException e) {
                    System.err.println("警告：跳过无效整数格式的数据 - " + trimmedData);
                }
            }
        }

        if (count < dataStrArray.length) {
            double[] result = new double[count];
            System.arraycopy(lineData, 0, result, 0, count);
            return result;
        }
        return lineData;
    }
}
