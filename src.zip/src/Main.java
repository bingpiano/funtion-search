import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
                                        /*测试顺序:*/
//最后运行       (运行顺序GenerateLinearData -> LinearFitter -> Main)

                                        /*类介绍*/
//测试时，该类如无其他需求，可直接运行测试
//该类仅用来测试不同查找方法所查找用到的时间，由于部分查找算法为ai生成，不能代表该算法实际速度，可根据需要优化这些算法，所提供算法仅供参考
//BOUND参数为测试数据大小，如：调整为1000：在所有数据中查询1000个随机生成的位于该组数据中的随机数，以供测试。
//数据文件为GenerateLinearData类中生成的数据,本类通过dataFilePath来设置该数据文件路径
//该类中，除了要设置数据文件路径，还需设置maxErrorFilePath，路径为LinearFitter设置的dataFilePath路径,以查找拟合函数的k,b,maxError
//B-tree查找由于仅返回当前数据查找成功与否，所以不支持一次性多数查找，要使用B-tree查找需将BOUND改为1，并且将B-tree代码注释取消

                                        /*测试（使用）方法：*/
// 1.运行GenerateLinearData类->生成数据
// 2.运行LinearFitter类->生成拟合函数
// 3.Main->查看测试结果
// 各个类中配置如无需求，无需更改，默认配置为1亿数据，
//  如果要改数据，方法一：请删除原数据文件(dataFilePath)及maxError文件(maxErrorFilePath),再按顺序重新运行 (推荐)
//             方法二：更改每个类的文件配置路径

                                        /*默认配置*/
//在所有数据中，查找1000个该组数据中的随机数
public class Main {
    private static final int BOUND = 1000;//最多可设为99999999
    private static final String dataFilePath = "increasing_data.txt"; // 数据文件路径
    private static final String maxErrorFilePath = "max_error.txt"; //△max

    public static int functionSearch(double maxError, double target, double k, double b, int[] arr, int length) {
        double leftIndex = (target - maxError - b) / k; //200ns
        double rightIndex = (target + maxError - b) / k;
        int left = leftIndex < 0 ? 0 : (int) leftIndex;
        int right = rightIndex > length ? length : (int) rightIndex + 1;
        // 二分查找逻辑
        while (left <= right) {
            // 计算中间索引，避免溢出
            int mid = left + (right - left) / 2;
            if (arr[mid] == target) {
                return mid;  // 找到目标值，返回索引
            } else if (arr[mid] < target) {
                left = mid + 1;  // 目标值在右侧，调整左边界
            } else {
                right = mid - 1;  // 目标值在左侧，调整右边界
            }
        }
        // 循环结束仍未找到，返回-1
        return -1;
    }


    public static void main(String args[]) throws IOException, ExecutionException, InterruptedException {
        List<Double> list = readDoubleData(maxErrorFilePath);
        double maxError=list.get(0);
        double k=list.get(1);
        double b=list.get(2);
        int[] targets = new int[BOUND];
        int[] resultIndexs = new int[BOUND];
        Random random = new Random();
        for (int i = 0; i < targets.length; i++) {
            targets[i] = random.nextInt(0, 1049934719);
        }


        List<Integer> data = readIntegerData(dataFilePath);
        if (data.isEmpty()) {
            System.err.println("数据文件为空或没有有效数据");
            return;
        }
        int[] intArray = convertToIntArray(data);
        int length = intArray.length;
        //二分查找-------------------------------------------------------------------------------------
        int[] correctIndex = new int[BOUND];
        System.out.println("JVM预热中...");
        for (int i = 0; i < BOUND; i++) {
            binarySearch(intArray, targets[i], length);
        }
        System.gc(); // 触发垃圾回收
        System.out.println("\033[34m开始二分查找\033[0m");
        // 记录开始时间（纳秒）
        long startTime = System.nanoTime();
        // 执行二分查找

        for (int i = 0; i < targets.length; i++) {
            resultIndexs[i] = binarySearch(intArray, targets[i], length);
        }
        // 记录结束时间（纳秒）
        long endTime = System.nanoTime();
        // 计算执行时间（纳秒）
        long durationNanos = endTime - startTime;
        // 转换为毫秒（可选）
        double durationMillis = durationNanos / 1_000_000.0;
        // 输出结果
        print(targets, resultIndexs);
        System.out.println("二分查找执行时间: " + durationNanos + " 纳秒");
        System.out.println("二分查找执行时间: " + durationMillis + " 毫秒");
        for (int i = 0; i < correctIndex.length; i++) {
            correctIndex[i] = resultIndexs[i];
        }

        //函数查找-------------------------------------------------------------------------------------
        initResultArr(resultIndexs);
        System.out.println("\033[34m开始函数查找\033[0m");
        // 记录开始时间（纳秒）
        startTime = System.nanoTime();
        // 执行函数查找
        for (int i = 0; i < targets.length; i++) {
            resultIndexs[i] = functionSearch(maxError, targets[i], k, b, intArray,length);
            //resultIndexs[i] = fastFunctionSearch(maxError, targets[i], k, b, intArray, 0.99, length);
        }
        // 记录结束时间（纳秒）
        endTime = System.nanoTime();
        // 计算执行时间（纳秒）
        durationNanos = endTime - startTime;
        // 转换为毫秒（可选）
        durationMillis = durationNanos / 1_000_000.0;
        // 输出结果
        print(targets, resultIndexs);
        System.out.println("函数查找执行时间: " + durationNanos + " 纳秒");
        System.out.println("函数查找执行时间: " + durationMillis + " 毫秒");
        printRight(correctIndex, resultIndexs);


        // 2. 二分查找 + 插值优化（适合均匀分布数据）----------------------------------------------------------------
        initResultArr(resultIndexs);
        System.out.println("\033[34m开始二分查找 + 插值优化查找\033[0m");
        // 记录开始时间（纳秒）
        startTime = System.nanoTime();
        // 执行函数查找
        for (int i = 0; i < targets.length; i++) {
            resultIndexs[i] = binaryWithInterpolation(intArray, targets[i]);
        }
        // 记录结束时间（纳秒）
        endTime = System.nanoTime();
        // 计算执行时间（纳秒）
        durationNanos = endTime - startTime;
        // 转换为毫秒（可选）
        durationMillis = durationNanos / 1_000_000.0;
        // 输出结果
        print(targets, resultIndexs);
        System.out.println(" 二分查找 + 插值优化执行时间: " + durationNanos + " 纳秒");
        System.out.println(" 二分查找 + 插值优化执行时间: " + durationMillis + " 毫秒");
        printRight(correctIndex, resultIndexs);


        // 3. 二分查找 + 块索引优化（适合大数据量）----------------------------------------------------------------
        initResultArr(resultIndexs);
        System.out.println("\033[34m开始二分查找 + 块索引优化查找\033[0m");
        int blockSize =8000;
        int blockCount = (intArray.length + blockSize - 1) / blockSize;
        int[] blockMax = new int[blockCount];
        int[] blockStart = new int[blockCount];
        // 记录开始时间（纳秒）
        startTime = System.nanoTime();
        // 执行函数查找
        for (int i = 0; i < targets.length; i++) {
            resultIndexs[i] = binaryWithBlockIndex(intArray,targets[i],blockSize,blockCount,blockMax,blockStart);
        }
        // 记录结束时间（纳秒）
        endTime = System.nanoTime();
        // 计算执行时间（纳秒）
        durationNanos = endTime - startTime;
        // 转换为毫秒（可选）
        durationMillis = durationNanos / 1_000_000.0;
        // 输出结果
        print(targets,resultIndexs);
        System.out.println("二分查找 + 块索引优化查找执行时间: " + durationNanos + " 纳秒");
        System.out.println("二分查找 + 块索引优化查找执行时间: " + durationMillis + " 毫秒");
        printRight(correctIndex,resultIndexs);

        //4. 二分查找 + 哈希缓存（适合高频查询）----------------------------------------------------------------
        initResultArr(resultIndexs);
        System.out.println("\033[34m开始二分查找 + 哈希缓存查找\033[0m");
        // 记录开始时间（纳秒）
        startTime = System.nanoTime();
        // 执行函数查找
        for (int i = 0; i < targets.length; i++) {
            resultIndexs[i] = binaryWithCache(intArray,targets[i]);
        }
        // 记录结束时间（纳秒）
        endTime = System.nanoTime();
        // 计算执行时间（纳秒）
        durationNanos = endTime - startTime;
        // 转换为毫秒（可选）
        durationMillis = durationNanos / 1_000_000.0;
        // 输出结果
        print(targets,resultIndexs);
        System.out.println("二分查找 + 哈希缓存查找执行时间: " + durationNanos + " 纳秒");
        System.out.println("二分查找 + 哈希缓存查找执行时间: " + durationMillis + " 毫秒");
        printRight(correctIndex,resultIndexs);

        // 5. 二分查找 + 并行计算（适合多核环境）----------------------------------------------------------------
        initResultArr(resultIndexs);
        System.out.println("\033[34m开始二分查找 + 并行计算查找\033[0m");
        // 记录开始时间（纳秒）
        startTime = System.nanoTime();
        // 执行函数查找
        for (int i = 0; i < targets.length; i++) {
            resultIndexs[i] = parallelBinarySearch(intArray,targets[i],8);
        }
        // 记录结束时间（纳秒）
        endTime = System.nanoTime();
        // 计算执行时间（纳秒）
        durationNanos = endTime - startTime;
        // 转换为毫秒（可选）
        durationMillis = durationNanos / 1_000_000.0;
        // 输出结果
        print(targets,resultIndexs);
        System.out.println("二分查找 + 并行计算: " + durationNanos + " 纳秒");
        System.out.println("二分查找 + 并行计算: " + durationMillis + " 毫秒");
        printRight(correctIndex,resultIndexs);






        // 5. B+树----------------------------------------------------------------
        // 首先向B+树插入数据
//        BPlusTree<Integer> bPlusTree = new BPlusTree<>(15);
//        for (int i = 0; i < intArray.length; i++) {
//            bPlusTree.insert(intArray[i], (long) i);
//        }
//        initResultArr(resultIndexs);
//        boolean exists = false;
//        System.out.println("\033[34m开始B+树查找\033[0m");
//        // 记录开始时间（纳秒）
//        startTime = System.nanoTime();
//        // 执行函数查找
//        // 测试存在的值
//        for (int i = 0; i < targets.length; i++) {
//            exists = bPlusTree.search(targets[i]);
//        }
//        // 记录结束时间（纳秒）
//        endTime = System.nanoTime();
//        // 计算执行时间（纳秒）
//        durationNanos = endTime - startTime;
//        // 转换为毫秒（可选）
//        durationMillis = durationNanos / 1_000_000.0;
//        // 输出结果
//        print(targets,resultIndexs);
//        System.out.println("存在/不存在:"+exists);
//        System.out.println("B+树: " + durationNanos + " 纳秒");
//        System.out.println("B+树: " + durationMillis + " 毫秒");
//        printRight(correctIndex,resultIndexs);



    }


    public static List<Integer> readIntegerData(String filePath) throws IOException {
        List<Integer> dataList = new ArrayList<>();

        // 使用try-with-resources确保流自动关闭
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            // 逐行读取文件内容
            while ((line = reader.readLine()) != null) {
                // 处理每行数据
                processLine(line, dataList);
            }
        }

        return dataList;
    }

    public static List<Double> readDoubleData(String filePath) throws IOException {
        List<Double> dataList = new ArrayList<>();

        // 使用try-with-resources确保流自动关闭
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            // 逐行读取文件内容
            while ((line = reader.readLine()) != null) {
                // 处理每行数据
                processDoubleLine(line, dataList);
            }
        }

        return dataList;
    }
    private static void processDoubleLine(String line, List<Double> dataList) {
        // 去除首尾空格
        String trimmedLine = line.trim();
        if (trimmedLine.isEmpty()) {
            return; // 跳过空行
        }

        // 按逗号分割数据
        String[] dataStrArray = trimmedLine.split(",");

        // 转换每个字符串为整数
        for (String dataStr : dataStrArray) {
            String trimmedData = dataStr.trim();
            if (!trimmedData.isEmpty()) { // 跳过空字符串
                try {
                    Double value = Double.parseDouble(trimmedData);
                    dataList.add(value);
                } catch (NumberFormatException e) {
                    // 处理格式错误的数据
                    System.err.println("警告：跳过无效整数格式的数据 - " + trimmedData);
                }
            }
        }
    }

    private static void processLine(String line, List<Integer> dataList) {
        // 去除首尾空格
        String trimmedLine = line.trim();
        if (trimmedLine.isEmpty()) {
            return; // 跳过空行
        }

        // 按逗号分割数据
        String[] dataStrArray = trimmedLine.split(",");

        // 转换每个字符串为整数
        for (String dataStr : dataStrArray) {
            String trimmedData = dataStr.trim();
            if (!trimmedData.isEmpty()) { // 跳过空字符串
                try {
                    int value = Integer.parseInt(trimmedData);
                    dataList.add(value);
                } catch (NumberFormatException e) {
                    // 处理格式错误的数据
                    System.err.println("警告：跳过无效整数格式的数据 - " + trimmedData);
                }
            }
        }
    }

    // 将List<Integer>转换为int[]数组
    public static int[] convertToIntArray(List<Integer> list) {
        if (list == null) {
            return new int[0]; // 或返回null，根据需求处理
        }
        return list.stream().mapToInt(Integer::intValue).toArray();
    }

    public static int binarySearch(int[] arr, int target, int length) {
        int left = 0;
        int right = length - 1;

        // 二分查找核心逻辑
        while (left <= right) {
            // 计算中间索引，避免溢出
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid;  // 找到目标值，返回索引
            } else if (arr[mid] < target) {
                left = mid + 1;  // 目标值在右侧，调整左边界
            } else {
                right = mid - 1;  // 目标值在左侧，调整右边界
            }
        }

        // 循环结束仍未找到，返回-1
        return -1;
    }

    // 2. 二分查找 + 插值优化
    public static int binaryWithInterpolation(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right && target >= arr[left] && target <= arr[right]) {
            // 插值计算中间位置（优化初始mid选择）
            int mid = left + (target - arr[left]) * (right - left) / (arr[right] - arr[left]);

            // 防止计算溢出导致的越界
            if (mid < left || mid > right) {
                mid = left + (right - left) / 2; // 退化为标准二分
            }

            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        // 检查边界值
        return (arr[left] == target) ? left : -1;
    }

    // 3. 二分查找 + 块索引优化
    public static int binaryWithBlockIndex(int[] arr, int target, int blockSize, int blockCount, int[] blockMax, int[] blockStart) {
        for (int i = 0; i < blockCount; i++) {
            blockStart[i] = i * blockSize;
            int end = Math.min((i + 1) * blockSize - 1, arr.length - 1);
            blockMax[i] = arr[end]; // 有序数组的块最大值是块尾元素
        }

        // 2. 二分查找块索引，定位目标所在块
        int blockLeft = 0;
        int blockRight = blockCount - 1;
        int targetBlock = -1;

        while (blockLeft <= blockRight) {
            int blockMid = blockLeft + (blockRight - blockLeft) / 2;
            if (blockMax[blockMid] >= target) {
                targetBlock = blockMid;
                blockRight = blockMid - 1;
            } else {
                blockLeft = blockMid + 1;
            }
        }

        // 3. 在目标块内执行二分查找
        if (targetBlock == -1) return -1;

        int left = blockStart[targetBlock];
        int right = Math.min((targetBlock + 1) * blockSize - 1, arr.length - 1);

        return binarySearchInRange(arr, target, left, right);
    }

    // 辅助方法：在指定范围内执行二分查找
    private static int binarySearchInRange(int[] arr, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    // 4. 二分查找 + 哈希缓存
    private static final Map<Integer, Integer> cache = new HashMap<>();

    public static int binaryWithCache(int[] arr, int target) {
        // 先查缓存
        if (cache.containsKey(target)) {
            int cachedIndex = cache.get(target);
            // 验证缓存有效性（防止数据被修改）
            if (cachedIndex >= 0 && cachedIndex < arr.length && arr[cachedIndex] == target) {
                return cachedIndex;
            }
            cache.remove(target); // 缓存无效，移除
        }

        // 缓存未命中，执行二分查找
        int index = binarySearch(arr, target);
        if (index != -1) {
            cache.put(target, index); // 存入缓存
        }
        return index;
    }

    // 5. 二分查找 + 并行计算
    public static int parallelBinarySearch(int[] arr, int target, int threadCount) throws InterruptedException, ExecutionException {
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        List<Future<Integer>> futures = new ArrayList<>();

        int segmentSize = (arr.length + threadCount - 1) / threadCount;

        // 分割任务到多个线程
        for (int i = 0; i < threadCount; i++) {
            final int start = i * segmentSize;
            final int end = Math.min((i + 1) * segmentSize - 1, arr.length - 1);

            futures.add(executor.submit(() -> {
                // 先判断目标是否在当前段范围内
                if (arr[start] > target || arr[end] < target) {
                    return -1;
                }
                // 在段内执行二分查找
                return binarySearchInRange(arr, target, start, end);
            }));
        }

        // 等待结果
        for (Future<Integer> future : futures) {
            int result = future.get();
            if (result != -1) {
                executor.shutdownNow();
                return result;
            }
        }
        executor.shutdown();
        return -1;
    }


    public static void print(int[] targets, int[] resultIndexs) {
        for (int i = 0; i < targets.length; i++) {
            if (i == targets.length) {
                System.out.println("查找完成");
                System.out.println("最后目标值 " + targets[i] + " 的索引是: " + resultIndexs[i]);
            }
        }
    }

    public static void printRight(int[] rights, int[] resultIndexs) {
        double numOfRight = 0;
        for (int i = 0; i < rights.length; i++) {
            if (rights[i] == resultIndexs[i]) {
                numOfRight++;
            }
        }
        double result = numOfRight / rights.length;
        System.out.println("\033[35m正确率为:\033[0m" + result*100 + "%");
    }


    public static void initResultArr(int[] arr) {
        System.out.println("\033[32m正在初始化结果索引数组\033[0m");
        for (int i = 0; i < arr.length; i++) {
            arr[i] = -2;
        }
    }

    public static int binarySearch(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;

        // 二分查找核心逻辑
        while (left <= right) {
            // 计算中间索引，避免溢出
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid;  // 找到目标值，返回索引
            } else if (arr[mid] < target) {
                left = mid + 1;  // 目标值在右侧，调整左边界
            } else {
                right = mid - 1;  // 目标值在左侧，调整右边界
            }
        }

        // 循环结束仍未找到，返回-1
        return -1;
    }




}
